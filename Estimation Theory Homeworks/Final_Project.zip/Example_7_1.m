% Example 7.1
% Book: Introduction to Optimal Estimation by E. W. Kamen and J. K. Su
% Author: SepideH Moazzeni
% 07/10/2022
% Complete!
%%
clc
clear all
close all
%%
sigma_wcx = 0.05;   %(km/s)
sigma_wcy = 0.08;   %(km/s)
sigma_vcx = 2;      %(km)
sigma_vcy = 2.25;   %(km)
x0 = 30;            %(km)
y0 = 20;            %(km)
vx0 = 100;      %(km/s)
vy0 = 100;      %(km/s)
%% Continous-time
A = [0 1 0 0;
    0 0 0 0;
    0 0 0 1;
    0 0 0 0];
B = [0 0;
    1 0;
    0 0;
    0 1];
C = [1 0 0 0;
    0 0 1 0];
D = 0;
T = 50e-3;
sys_d = c2d(ss(A,B,C,D),T);
%% Discrete-time
phi = sys_d.a;
Gamma = eye(4);
C = sys_d.c;
% A.45
Q = [T^3*sigma_wcx^2/3 T^2*sigma_wcx^2/2 0 0;
    T^2*sigma_wcx^2/2 T*sigma_wcx^2 0 0;
    0 0 T^3*sigma_wcy^2/3 T^2*sigma_wcy^2/2;
    0 0 T^2*sigma_wcy^2/2 T*sigma_wcy^2];
R = [sigma_vcx^2/T 0;
    0 sigma_vcy^2/T];
%%
t = 0:T:30;
num_data = length(t);

w = sqrtm(Q)*randn(4,num_data);
v = sqrtm(R)*randn(2,num_data);

x(:,1) = [x0 0 y0 0]';%[x0 0 y0 0]';
Pm{1} = 1*diag([50 10 50 10]);
z0 = C*[x0 vx0 y0 vy0]' + v(:,1);
xhm(:,1) = [z0(1) 0 z0(2) 0]';

for i=1:num_data-1
   % System
   x(:,i+1) = phi*x(:,i) + Gamma * w(:,i);
   s(:,i) = C*x(:,i);
   z(:,i) = s(:,i) + v(:,i);
   
   %------- Kalman Filter -------%
   % Measurment update
   K{i} = Pm{i} * C' * inv(C*Pm{i}*C'+R);
   xh(:,i) = xhm(:,i) + K{i} *(z(:,i)-C*xhm(:,i));
   P{i} = Pm{i} - K{i} * C * Pm{i};
   
   % time update
   xhm(:,i+1) = phi * xh(:,i);
   Pm{i+1} = phi * P{i} * phi' + Gamma * Q * Gamma';
   
   er = x(:,i) - xh(:,i);
   sum_x(i) = er' * er;
   mse_actual(i) = mean(sum_x(1:i));
   mse_estimate(i) = trace(P{i});
end
shat = C*xh;
%%
close all

figure(1);
sgtitle('Horizontal Position') 
subplot(211)
plot(t(1:end-1),z(1,:)),grid on,grid minor
ylabel('$$z_1$$ Observation (km)','Interpreter','Latex','fontsize',12)

subplot(212)
plot(t,x(1,:)),grid on,grid minor
hold on
plot(t(2:end),shat(1,:))
ylabel('Horizontal Position (km)','Interpreter','Latex','fontsize',12)
xlabel('time (s)','Interpreter','Latex','fontsize',12)
legend('$$x(n)$$','$$\hat{x}(n)$$','Interpreter','Latex','Location','Best','fontsize',12)

set(findall(figure(1),'type','line'),'linewidth',1)

figure(2);
sgtitle('Vertical Position') 
subplot(211)
plot(t(1:end-1),z(2,:)),grid on,grid minor
ylabel('$$z_2$$ Observation (km)','Interpreter','Latex','fontsize',12)

subplot(212)
plot(t,x(3,:)),grid on,grid minor
hold on
plot(t(2:end),shat(2,:))
ylabel('Vertical Position (km)','Interpreter','Latex','fontsize',12)
xlabel('time (s)','Interpreter','Latex','fontsize',12)
legend('$$y(n)$$','$$\hat{y}(n)$$','Interpreter','Latex','Location','Best','fontsize',12)

set(findall(figure(2),'type','line'),'linewidth',1)

figure(3);
sgtitle('Velocity') 
subplot(211)
plot(t,x(2,:)),grid on,grid minor
hold on
plot(t(2:end),xh(2,:))
ylabel('Horizontal Velocity (km/s)','Interpreter','Latex','fontsize',12)
legend('$$\dot{x}(n)$$','$$\hat{\dot{x}}(n)$$','Interpreter','Latex','Location','Best','fontsize',12)

subplot(212)
plot(t,x(4,:)),grid on,grid minor
hold on
plot(t(2:end),xh(4,:))
ylabel('Vertical Velocity (km/s)','Interpreter','Latex','fontsize',12)
xlabel('time (s)','Interpreter','Latex','fontsize',12)
legend('$$\dot{y}(n)$$','$$\hat{\dot{y}}(n)$$','Interpreter','Latex','Location','Best','fontsize',12)

set(findall(figure(3),'type','line'),'linewidth',1)
%%
figure(4);
subplot(211)
plot(t(2:end),mse_actual),grid on,grid minor
hold on
plot(t(2:end),mse_estimate)
ylabel('Squared error','Interpreter','Latex','fontsize',12)
legend('MSE Actual','MSE Estimated')
for j=1:200
    for i=1:num_data-1
        % System
        x(:,i+1) = phi*x(:,i) + Gamma * w(:,i);
        s(:,i) = C*x(:,i);
        z(:,i) = s(:,i) + v(:,i);
        
        %------- Kalman Filter -------%
        % Measurment update
        K{i} = Pm{i} * C' * inv(C*Pm{i}*C'+R);
        xh(:,i) = xhm(:,i) + K{i} *(z(:,i)-C*xhm(:,i));
        P{i} = Pm{i} - K{i} * C * Pm{i};
        
        % time update
        xhm(:,i+1) = phi * xh(:,i);
        Pm{i+1} = phi * P{i} * phi' + Gamma * Q * Gamma';
        
        er = x(:,i) - xh(:,i);
        sum_x(i) = er' * er;
        mse_actual(i,j) = mean(sum_x(1:i));
        mse_estimate(i,j) = trace(P{i});
    end
end
for i=1:num_data-1
    mse_ave_estimate(i) = mean(mse_estimate(i,:));
    mse_ave_actual(i) = mean(mse_actual(i,:));
end


subplot(212)
plot(t(2:end),mse_ave_actual),grid on,grid minor
hold on
plot(t(2:end),mse_ave_estimate)
legend('MSE Actual','MSE Estimated')

ylabel('Squared error','Interpreter','Latex','fontsize',12)
xlabel('time (s)','Interpreter','Latex','fontsize',12)
set(findall(figure(4),'type','line'),'linewidth',1.2)