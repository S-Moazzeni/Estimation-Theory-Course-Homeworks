clc
clear all
close all
warning off
%%
Ts=0.1;
tf1=1.5;
t1=0:Ts:tf1;
tf2=5;
t2=0:Ts:tf2;
%%
a0=1;
a1=0.2;
a2=-1;
noise=randn(1,length(t2));
sigma=1;
noise=sqrt(sigma)*(noise-mean(noise));
for i=1:length(t2)
    f(i)=a0+a1*sin(2*t2(i))+a2*exp(-0.5*t2(i))+noise(i);
end
%% RLS Algorithm
n=3;                     %Number of Regressor
P=10^3*eye(n);
theta_hat1(:,1)=0*randn(n,1);

for i=2:length(t1)
    gamma1(i,:)=[1 sin(2*t1(i)) exp(-0.5*t1(i))];
    K = P*gamma1(i,:)'/ ( 1 + gamma1(i,:)*P*gamma1(i,:)');
    P = (eye(n)-K*gamma1(i,:))*P;
    theta_hat1(:,i) = theta_hat1(:,i-1) + K*(f(i)-gamma1(i,:)*theta_hat1(:,i-1));
    P_eig(:,i)=eig(P);
end
S_hat1=gamma1*theta_hat1(:,end);
theta_hat1(:,end)
e1=mse(S_hat1-f)


P=10^3*eye(n);
theta_hat2(:,1)=0*randn(n,1);
for i=2:length(t2)
    gamma2(i,:)=[1 sin(2*t2(i)) exp(-0.5*t2(i))];
    K = P*gamma2(i,:)'/ ( 1 + gamma2(i,:)*P*gamma2(i,:)');
    P = (eye(n)-K*gamma2(i,:))*P;
    theta_hat2(:,i) = theta_hat2(:,i-1) + K*(f(i)-gamma2(i,:)*theta_hat2(:,i-1));
    P_eig(:,i)=eig(P);
end
S_hat2=gamma2*theta_hat2(:,end);
theta_hat2(:,end)
e2=mse(S_hat2-f)
%% Plot Result
figure(1) % Theta Convergence
subplot(321), plot(t1,theta_hat1(1,:)),hold on ,plot(t1,a0*ones(1,length(theta_hat1)),'--r'), 
title('$$15 Samples$$','Interpreter','Latex','fontsize',12)
ylabel('$$\hat{a}_0$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(323), plot(t1,theta_hat1(2,:)),hold on ,plot(t1,a1*ones(1,length(theta_hat1)),'--r'),
ylabel('$$\hat{a}_1$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(325), plot(t1,theta_hat1(3,:)),hold on ,plot(t1,a2*ones(1,length(theta_hat1)),'--r'),
ylabel('$$\hat{a}_2$$','Interpreter','Latex','fontsize',12), grid on, grid minor
xlabel('t (s)','Interpreter','Latex','fontsize',10)

subplot(322), plot(t2,theta_hat2(1,:)),hold on ,plot(t2,a0*ones(1,length(theta_hat2)),'--r'),
title('$$50 Samples$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(324), plot(t2,theta_hat2(2,:)),hold on ,plot(t2,a1*ones(1,length(theta_hat2)),'--r'), grid on, grid minor
subplot(326), plot(t2,theta_hat2(3,:)),hold on ,plot(t2,a2*ones(1,length(theta_hat2)),'--r'), grid on, grid minor
xlabel('t (s)','Interpreter','Latex','fontsize',10)
set(findall(figure(1),'type','line'),'linewidth',1.5)
