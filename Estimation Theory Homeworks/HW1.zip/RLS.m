clc
clear all
close all
warning off
%%
Ts=0.1;
tf=9.9;
t=0:Ts:tf;
%%
a0=1;
a1=0.2;
a2=-1;
for i=1:length(t)
    f(i)=a0+a1*sin(2*t(i))+a2*exp(-0.5*t(i));
end
%% RLS Algorithm
n=3;                     %Number of Regressor
P=10^3*eye(n);
theta_hat(:,1)=0*randn(n, 1);

for i=2:length(t)
    gamma(i,:)=[1 sin(2*t(i)) exp(-0.5*t(i))];
    K = P*gamma(i,:)'/ ( 1 + gamma(i,:)*P*gamma(i,:)');
    P = (eye(n)-K*gamma(i,:))*P;
    theta_hat(:,i) = theta_hat(:,i-1) + K*(f(i)-gamma(i,:)*theta_hat(:,i-1));
    P_eig(:,i)=eig(P);
end
S_hat=gamma*theta_hat(:,end);

%% Plot Result
figure(1) % Theta Convergence
subplot(311), plot(theta_hat(1,:)),hold on ,plot(a0*ones(1,length(theta_hat)),'--r'), title('a_0'), grid on, grid minor
subplot(312), plot(theta_hat(2,:)),hold on ,plot(a1*ones(1,length(theta_hat)),'--r'), title('a_1'), grid on, grid minor
subplot(313), plot(theta_hat(3,:)),hold on ,plot(a2*ones(1,length(theta_hat)),'--r'), title('a_2'), grid on, grid minor
set(findall(figure(1),'type','line'),'linewidth',1.5)

% figure(3) % EIG convergence
% subplot(331), plot(P_eig(1,:),'k-','LineWidth',2), title('Peig0'), grid on, grid minor
% subplot(332), plot(P_eig(2,:),'k-','LineWidth',2), title('Peig1'), grid on, grid minor
% subplot(333), plot(P_eig(3,:),'k-','LineWidth',2), title('Peig2'), grid on, grid minor
