clc
clear all
close all
warning off
%%
Ts=0.1;
tf=10;
t=0:Ts:tf;
%%
a0=1;
a1=0.2;
a2=-1;
noise=randn(1,length(t));
sigma=0.01;
noise=sqrt(sigma)*(noise-mean(noise));
for i=1:length(t)
    f(i)=a0+a1*sin(2*t(i))+a2*exp(-0.5*t(i))+noise(i);
end
%% RLS Algorithm with P0 high
n=3;                     %Number of Regressor
P1=10^4*eye(n);
theta_hat1(:,1)=0*randn(n,1);

for i=2:length(t)
    gamma(i,:)=[1 sin(2*t(i)) exp(-0.5*t(i))];
    K = P1*gamma(i,:)'/ ( 1 + gamma(i,:)*P1*gamma(i,:)');
    P1 = (eye(n)-K*gamma(i,:))*P1;
    theta_hat1(:,i) = theta_hat1(:,i-1) + K*(f(i)-gamma(i,:)*theta_hat1(:,i-1));
    P_eig1(:,i)=eig(P1);
end
S_hat1=gamma*theta_hat1(:,end);
e1=mse(S_hat1-f)
%% RLS Algorithm with P0 low
n=3;                     %Number of Regressor
P2=10^1*eye(n);
theta_hat2(:,1)=0*randn(n, 1);

for i=2:length(t)
    gamma(i,:)=[1 sin(2*t(i)) exp(-0.5*t(i))];
    K = P2*gamma(i,:)'/ ( 1 + gamma(i,:)*P2*gamma(i,:)');
    P2 = (eye(n)-K*gamma(i,:))*P2;
    theta_hat2(:,i) = theta_hat2(:,i-1) + K*(f(i)-gamma(i,:)*theta_hat2(:,i-1));
    P_eig2(:,i)=eig(P2);
end
S_hat2=gamma*theta_hat2(:,end);
e2=mse(S_hat2-f)
%% Plot Result
figure(1) % Theta Convergence
subplot(321), plot(t,theta_hat1(1,:)),hold on ,plot(t,a0*ones(1,length(theta_hat1)),'--r'), 
title('$$P_0=10^4I$$','Interpreter','Latex','fontsize',12)
ylabel('$$\hat{a}_0$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(323), plot(t,theta_hat1(2,:)),hold on ,plot(t,a1*ones(1,length(theta_hat1)),'--r'),
ylabel('$$\hat{a}_1$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(325), plot(t,theta_hat1(3,:)),hold on ,plot(t,a2*ones(1,length(theta_hat1)),'--r'),
ylabel('$$\hat{a}_2$$','Interpreter','Latex','fontsize',12), grid on, grid minor
xlabel('t (s)','Interpreter','Latex','fontsize',10)

subplot(322), plot(t,theta_hat2(1,:)),hold on ,plot(t,a0*ones(1,length(theta_hat2)),'--r'),
title('$$P_0=10^1I$$','Interpreter','Latex','fontsize',12), grid on, grid minor
subplot(324), plot(t,theta_hat2(2,:)),hold on ,plot(t,a1*ones(1,length(theta_hat2)),'--r'), grid on, grid minor
subplot(326), plot(t,theta_hat2(3,:)),hold on ,plot(t,a2*ones(1,length(theta_hat2)),'--r'), grid on, grid minor
xlabel('t (s)','Interpreter','Latex','fontsize',10)
set(findall(figure(1),'type','line'),'linewidth',1.5)
