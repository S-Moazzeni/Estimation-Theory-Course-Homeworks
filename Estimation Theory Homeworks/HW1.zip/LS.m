clc
clear all
close all
warning off
%%
Ts=0.1;
tf=0.5;
t=0:Ts:tf;
%%
a0=1;
a1=0.2;
a2=-1;
for i=1:length(t)
    f(i)=a0+a1*sin(2*t(i))+a2*exp(-0.5*t(i));
end
%%
gamma=[];
Z=[];
for i=1:length(t)
    gamma=[gamma;1 sin(2*t(i)) exp(-0.5*t(i))];
    Z=[Z;f(i)];
    theta_hat(:,i)=inv(gamma'*gamma)*gamma'*Z;
end
%%
figure(1)
plot(t,theta_hat,'-o')
legend('$$\hat{a}_0$$','$$\hat{a}_1$$','$$\hat{a}_2$$','Interpreter','Latex')
grid on,grid minor
set(findall(figure(1),'type','line'),'linewidth',1.5)
