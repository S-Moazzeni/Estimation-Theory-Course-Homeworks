clc
clear all
close all
%% (b)
num_data = 100;
n = 1:num_data;
s = cos(0.04*pi*n);
y = randn(1,num_data);
y = ((y-mean(y))./std(y));
mean(y)
var(y)
%% (c)
b1 = 1;
a1 = [1 -0.7];
v = filter(b1,a1,y);
%
b2 = 1;
a2 = [1 0.5 -0.36];
vprime = filter(b2,a2,y);
%
z = s + v;
%
figure(1);
subplot(211)
plot(s),grid on,grid minor
hold on
plot(z)
legend('s','z')

subplot(212)
plot(vprime),grid on,grid minor
legend('vprime')

set(findall(figure(1),'type','line'),'linewidth',1.5)
%% (d)
% Autocorrelation
Rvprime=zeros(1,num_data);
for k=1:num_data
    S=0;
    for i=k+1:num_data
        S=S+vprime(i)*vprime(i-k+1);
    end
    Rvprime(k) = S/num_data;
end

Rvvprime=zeros(1,num_data);
for k=1:num_data
    S=0;
    for i=k+1:num_data
        S=S+v(i)*vprime(i-k+1);
    end
    Rvvprime(k) = S/num_data;
end
%% (e)  F1R Wiener smoothing filter
N = [4 6 8]; % filter length
figure(2);
plot(s),grid on,grid minor
hold on
for k = 1:3
    A = [];
    B = [];
    for i=1:N(k)
        A = [ A ; [ Rvprime(i:-1:1) Rvprime(2:N(k)-i+1)] ];
        B = [ B ;  Rvvprime(i) ];
    end
    h = inv(A)*B;
    %% (f)
    vhat = filter(h,1,vprime);
    shat = z - vhat;    
    plot(shat)
    %% (g)
    varv = cov(v);
    Rv0 = varv;
    MSEv = Rv0 - h'*B
    Exp_MSEv = 1/num_data*(v-vhat)*(v-vhat)'
end
legend('s','shat (N=4)','shat (N=6)','shat (N=8)')
set(findall(figure(2),'type','line'),'linewidth',1.2);