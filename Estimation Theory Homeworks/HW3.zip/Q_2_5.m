% Q 2.5 of HW3 Estimation Theory
% Sepideh Moazzeni 40001956
%%
clc;clear;close all
%% generate y
N=50;
x=randn(N,1);
x=x-mean(x);
y=sqrt(8)*x/std(x);
%% about y!
% Mean
eta_h_y1=mean(y);
eta_h_y2=1/N*sum(y);
% Variance
sigma_h_y1=cov(y);
sigma_h_y2=1/(N-1)*sum((y-eta_h_y2).^2);
% Autocorrelation
Ry=zeros(1,50);
for k=1:N
    S=0;
    for i=k+1:N
        S=S+y(i)*y(i-k+1);
    end
    Ry(k)=1/(N*sigma_h_y2)*S;
end
close all

figure;plot(0:N-1,Ry,'k')
hold on
autocorr(y,49)
legend('$$Estimated R_y$$','$$Autocorr (Matlab)$$','Interpreter','Latex','fontsize',10)
ylabel('$$R_y$$','Interpreter','Latex','fontsize',15)
title('Auto Correlation','Interpreter','Latex','fontsize',15)

% Power Spectrum density
figure;
[Wy,Sy]=ccorr2pspec(Ry);
%%
plot(Wy,Sy,'linewidth',1.5)
hold on
grid on
xlabel('$$\omega_y$$','Interpreter','Latex','fontsize',15')
ylabel('$$S_y$$','Interpreter','Latex','fontsize',15)
title('Estimated Power Spectrum Of Y')
%% Filter
b=[1 1.25];
a=[1 -0.8 0.5];
s=filter(b,a,y);
figure;
subplot(211),plot(y,'r','LineWidth',1.5)
ylabel('$$Y (input)$$','Interpreter','Latex','fontsize',15)
subplot(212),plot(s,'b','LineWidth',1.5)
xlabel('$$Sample$$','Interpreter','Latex','fontsize',15')
ylabel('$$S (output)$$','Interpreter','Latex','fontsize',15)
%% about S!
% Mean
eta_h_s1=mean(s);
eta_h_s2=1/N*sum(s);
% Variance
sigma_h_s1=cov(s);
sigma_h_s2=1/(N-1)*sum((s-eta_h_s2).^2);
% Autocorrelation
Rs=zeros(1,50);
for k=1:N
    S=0;
    for i=k+1:N
        S=S+s(i)*s(i-k+1);
    end
    Rs(k)=1/(N*sigma_h_s2)*S;
end
figure;plot(0:N-1,Rs,'k')
hold on
autocorr(s,49)
legend('$$Estimated R_s$$','$$Autocorr (Matlab)$$','Interpreter','Latex','fontsize',10)
ylabel('$$R_s$$','Interpreter','Latex','fontsize',15)
title('Auto Correlation','Interpreter','Latex','fontsize',15)
%% Power Spectrum density
figure;
[Ws,Ss]=ccorr2pspec(Rs);
plot(Ws,Ss,'linewidth',1.5)
hold on
grid on
xlabel('$$\omega_s$$','Interpreter','Latex','fontsize',15')
ylabel('$$S_s$$','Interpreter','Latex','fontsize',15)
title('Estimated Power Spectrum Of S')
%% Power Spectrum density S , Y
figure;
plot(Wy,Sy,'linewidth',1.5)
hold on
plot(Ws,Ss,'linewidth',1.5)
grid on
xlabel('$$\omega_s$$','Interpreter','Latex','fontsize',15')
legend('$$S_y$$','$$S_s$$','Interpreter','Latex','fontsize',15)
title('Estimated Power Spectrum')

