function [W, S] = ccorr2pspec(R)
%CCORR2PSPEC Convert cross-correlation to power
% density spectrum
%ccorr2pspec(R) does not return anything but plots
% the spectrum.
%S = ccorr2pspec(R) returns the spectrurn.
% [W, S] = ccorr2pspec(R) returns a frequency vector
% and the spectrurn. Use plot(W,S) to view the
% spectrum.
%JKS 19 Sep 1993
L=length(R);
inW = 2*pi*[0:(L-1)]/L;
inS = real(fft(R,L));
if nargout == 0
    plot(inW, inS)
    xlabel('frequency w (radians)')
    ylabel( 'S(w)')
    title('Estirnated power density spectrurn')
elseif nargout == 1
    W=inW;
else
    W=inW;
    S=inS;
end