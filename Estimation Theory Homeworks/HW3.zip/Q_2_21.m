clc
clear
close all
%%
for k=1:11
    Ry(k)=1.067*(-0.25)^(k-1);
end
plot(0:10,Ry,'linewidth',1.5)
xlabel('Lag','Interpreter','Latex','fontsize',15)
ylabel('$$R_y(k)$$','Interpreter','Latex','fontsize',15)
