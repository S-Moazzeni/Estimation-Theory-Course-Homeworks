clc
clear all
close all
%%
pdx = makedist('Uniform','lower',0,'upper',4); % Uniform distribution with a = -2 and b = 2
pdv = makedist('Uniform','lower',-1,'upper',1); % Uniform distribution with a = -2 and b = 1
% Compute the pdfs for the  uniform distributions.
x = -3:.01:5;
pdfx = pdf(pdx,x);
pdfv = pdf(pdv,x);
% Plot the pdfs on the same axis.
figure;
subplot(211)
plot(x,pdfx,'k:','LineWidth',2);
hold on;
plot(x,pdfv,'b-.','LineWidth',2);
legend({'x (a=0,b=4)','v (a=-1,b=1)'},'Location','best');
xlabel('Observation')
ylabel('Probability Density')
hold off;
%%
subplot(212)
plot(-6:0.01:10,conv(pdfx,pdfv),'r','LineWidth',2)
xlabel('Observation')
ylabel('Probability Density Z')
