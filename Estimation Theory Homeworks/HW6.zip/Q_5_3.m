% Q 5.3
% Book: Introduction to Optimal Estimation by E. W. Kamen and J. K. Su
% Author: SepideH Moazzeni
% 6/21/2022
% Complete
%%
clc
clear all
close all
%%
num_data = 200;
phi = [0 1;0 0];
Gamma = [1/sqrt(2) 1/sqrt(2)]';
C = [1 0];
Q = 1;
R = 1;
%%
w = randn(1,num_data);
w = ((w-mean(w))./std(w));

v = randn(1,num_data);
v = ((v-mean(v))./std(v));
x(:,1) = randn(2,1);
for i=1:num_data-1
   x(:,i+1) = phi*x(:,i) + Gamma * w(:,i);
end
s = C*x ;
z = s + v ;
%%
Pm{1} = 10*eye(2);
xhm(:,1) = zeros(2,1);

for n=1:num_data-1
   % Measurment update
   K{n} = Pm{n} * C' * inv(C*Pm{n}*C'+R);
   xh(:,n) = xhm(:,n) + K{n} *(z(:,n)-C*xhm(:,n));
   P{n} = Pm{n} - K{n} * C * Pm{n};
   
   % time update
   xhm(:,n+1) = phi * xh(:,n);
   Pm{n+1} = phi * P{n} * phi' + Gamma * Q * Gamma';
         
   MSE_P(n) = trace(P{n});
   MSE_error(n)= mse(s(:,1:n)-C*xh(:,1:n));
end
shat = C*xh;
%%
figure(1);
subplot(211)
plot(s),grid on,grid minor
hold on
plot(C*xh)
legend('s','shat')

subplot(212)
plot(z-C*xhm),grid on,grid minor
hold on
plot(v)
legend('innovation','v')

set(findall(figure(1),'type','line'),'linewidth',1)

figure(2)
plot(MSE_P),grid on,grid minor
hold on
plot(MSE_error)
legend('Estimated MSE','Actual MSE')
set(findall(figure(2),'type','line'),'linewidth',1)
%%
MSEe = trace(P{n})
mse(s(end)-C*xh(:,n))