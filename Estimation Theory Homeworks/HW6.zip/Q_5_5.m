% Q 5.5
% Book: Introduction to Optimal Estimation by E. W. Kamen and J. K. Su
% Author: SepideH Moazzeni
% 6/21/2022
% Complete
%%
clc
clear all
close all
%%
num_data = 200;
w = randn(1,num_data);
w = sqrt(2)*((w-mean(w))./std(w));
s = filter([0 1 -1],1,w);
%%
v = randn(1,num_data);
v = ((v-mean(v))./std(v));
%%
z = s + v;
%%
phi = [0 -1;0 0];
Gamma = [1 1]';
C = [1 0];
Q = 2*eye(1);
R = 1*eye(1);
%%
Pm{1} = 1e3*eye(2);
xhm(:,1) = zeros(2,1);

for n=1:num_data-1
   % Measurment update
   K{n} = Pm{n} * C' * inv(C*Pm{n}*C'+R);
   xh(:,n) = xhm(:,n) + K{n} *(z(:,n)-C*xhm(:,n));
   P{n} = Pm{n} - K{n} * C * Pm{n};
   
   % time update
   xhm(:,n+1) = phi * xh(:,n);
   Pm{n+1} = phi * P{n} * phi' + Gamma * Q * Gamma';
   
   MSE_P(n) = trace(P{n});
   MSE_error(n)= mse(s(:,1:n)-C*xh(:,1:n));
end
shat = C*xh;
%%
figure(1);
plot(s),grid on,grid minor
hold on
plot(shat)
legend('s','shat','Location','best')

figure(2)
plot(MSE_P),grid on,grid minor
hold on
plot(MSE_error)
legend('Estimated MSE','Actual MSE')
set(findall(figure(2),'type','line'),'linewidth',1)
%%
MSEe = trace(P{n})