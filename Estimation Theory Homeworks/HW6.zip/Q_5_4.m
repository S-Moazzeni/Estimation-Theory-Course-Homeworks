% Q 5.4
% Book: Introduction to Optimal Estimation by E. W. Kamen and J. K. Su
% Author: SepideH Moazzeni
% 6/21/2022
% Complete
%%
clc
clear all
close all
%%
num_data = 100;
a = 2;
s = a*cos((1:num_data)*pi);
%%
v = randn(1,num_data);
v = sqrt(2)*((v-mean(v))./std(v));
%%
z = s + v;
%%
phi = -1;
Gamma = 0;
C = a;
Q = 0;
R = 2;
%%
Pm{1} = 1e3;
xhm(1) = randn;

for n=1:num_data-1
   % Measurment update
   K{n} = Pm{n} * C' * inv(C*Pm{n}*C'+R);
   xh(n) = xhm(n) + K{n} *(z(n)-C*xhm(n));
   sh(n) = C*xh(n);
   P{n} = Pm{n} - K{n} * C * Pm{n};
   
   % time update
   xhm(:,n+1) = phi * xh(:,n);
   Pm{n+1} = phi * P{n} * phi' + Gamma * Q * Gamma';
   
   MSE_P(n) = trace(P{n});
   MSE_error(n)= mse(s(:,1:n)-C*xh(:,1:n));
end
%%
figure(1);
subplot(211)
plot(s),grid on,grid minor
hold on
plot(sh(1,:))
legend('s','shat','Location','best')
ylim([-3 3])

subplot(212)
plot(z-C*xhm),grid on,grid minor
hold on
plot(v)
legend('innovation','v')
set(findall(figure(1),'type','line'),'linewidth',1)

figure(2)
plot(MSE_P),grid on,grid minor
hold on
plot(MSE_error)
legend('Estimated MSE','Actual MSE')
set(findall(figure(2),'type','line'),'linewidth',1)
%%
MSEe = trace(P{n})