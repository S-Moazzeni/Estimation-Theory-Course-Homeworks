clc
clear all
close all
%%
phi = [0.15 0.35 0.35;
    0.15 0.25 -0.15;
    0.2 -0.1 0.3];
Gamma = [0.4 0;0 0.5;0 0];
C = eye(3);
Q = 15*eye(2);
R = 4*eye(3);
N = 100;
%%
w = randn(2,N);
w = sqrt(15)*((w-mean(w))./std(w));
%
v = randn(3,N);
v = sqrt(4)*((v-mean(v))./std(v));
%
x(:,1) = zeros(3,1);
for i=1:N-1
   x(:,i+1) = phi*x(:,i) + Gamma * w(:,i);
end
s = x ;
z = s + v ;
%%
Pm{1} = 1500*eye(3);
xhm(:,1) = randn(3,1);

for k=1:N-1
   % Measurment update
   K{k} = Pm{k} * C' * inv(C*Pm{k}*C'+R);
   xh(:,k) = xhm(:,k) + K{k} *(z(:,k)-C*xhm(:,k));
   P{k} = Pm{k} - K{k} * C * Pm{k};
   
   % time update
   xhm(:,k+1) = phi * xh(:,k);
   Pm{k+1} = phi * P{k} * phi' + Gamma * Q * Gamma';
   
   MSE_P(k) = trace(P{k});
   MSE_error(k)= mse(s(:,1:k)-C*xh(:,1:k));
end
shat = C*xh;
%%
figure(1)
subplot(231)
plot(x(1,:));hold on,plot(xh(1,:)),legend('x_1','xh_1'),grid on,grid minor
subplot(232)
plot(x(2,:));hold on,plot(xh(2,:)),legend('x_2','xh_2'),grid on,grid minor
subplot(233)
plot(x(3,:));hold on,plot(xh(3,:)),legend('x_3','xh_3'),grid on,grid minor

subplot(234)
plot(z(1,1:end-1)-xh(1,:)),grid on,grid minor
hold on
plot(v(1,:))
legend('innovation','v')

subplot(235)
plot(z(2,1:end-1)-xh(2,:)),grid on,grid minor
hold on
plot(v(2,:))
legend('innovation','v')

subplot(236)
plot(z(3,1:end-1)-xh(3,:)),grid on,grid minor
hold on
plot(v(3,:))
legend('innovation','v')

set(findall(figure(1),'type','line'),'linewidth',1)

figure(2)
plot(MSE_P),grid on,grid minor
hold on
plot(MSE_error)
legend('mse p','mse error')
set(findall(figure(2),'type','line'),'linewidth',1)
%%
MSE_P = trace(P{k})
mse(s(:,2:end)-shat)