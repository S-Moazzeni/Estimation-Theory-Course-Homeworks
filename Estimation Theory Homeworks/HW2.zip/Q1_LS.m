clc;clear all;close all
warning 'off'
%% Time of Simulation
Ts = 0.1;
Tf = 10;
t = 0:Ts:Tf;
N = length(t); % Number of Samples
%% System
Gd=tf([3.548 24.76 -3.875 -15.36 -1.061],[1 -3.463 4.765 -3.257 1.107 -0.1496],Ts);
%% Input
noise = randn(1,N);
sigma_u = 1;
% white noise
% u = sqrt(sigma_u)*(noise-mean(noise));
% step
% u = ones(1,N);
% square 1 Hz
u = gensig('square',1,Tf,Ts)';
pe_of_u = pexcit(iddata([],u',Ts))
figure(1),plot(t,u),grid on
title('Input'),xlabel('Time (s)');
set(findall(figure(1),'type','line'),'linewidth',1.2)
%% Preparation data for identification
B = cell2mat(Gd.num); % Numerator polynomial coefficients
A = cell2mat(Gd.den); % Denumerator polynomial coefficients
na = length(A)-1;
nb = length(B)-1;
u_delay=[zeros(1,Gd.ioDelay) u(1:end-Gd.ioDelay)];
noise=randn(1,length(t));
sigma_n=1;
noise=sqrt(sigma_n)*(noise-mean(noise));
for i=1:N
    if (i-na)<1
        y(i)=0;
    else
        y(i)=-A(2:end)*y(i-1:-1:i-na)'+B(2:end)*u_delay(i-1:-1:i-nb)'+noise(i);
    end
end
%%
gamma=[];
Z=[];
for i=na+nb+1:N
    gamma=[gamma;-y(i-1:-1:i-na) u_delay(i-1:-1:i-nb)];
    Z=[Z;y(i)];
    theta_hat(:,i)=pinv(gamma'*gamma)*gamma'*Z;
end
S_hat=gamma*theta_hat(:,end);
Real=[A(2:end)';B(2:end)'];
Estimation=theta_hat(:,end);
T = table(Real,Estimation);
disp(T)
e=mse(S_hat-y)
%% ploting Parameters
figure(2)
sgtitle('LS Algorithm with Square Signal as Input','Interpreter','Latex','fontsize',12)

for i=1:5
    subplot(5,2,2*i-1)
    plot(t,theta_hat(i,:),'b');
    grid on
    ylabel(sprintf('a%d',i),'Interpreter','Latex','fontsize',11);
    hold on
    plot(t,A(i+1).*ones(1,N),'r--')
    hold off
end
xlabel('Time (s)','Interpreter','Latex','fontsize',11)
for i=1:5
    subplot(5,2,2*i)
    plot(t,theta_hat(i+5,:),'b')
    grid on
    ylabel(sprintf('b%d',i),'Interpreter','Latex','fontsize',11);
    hold on
    plot(t,B(i+1).*ones(1,N),'r--')
    hold off
end
xlabel('Time (s)','Interpreter','Latex','fontsize',11)
set(findall(figure(2),'type','line'),'linewidth',1.2)
