clc
clear all
close all
%%
N = 35;
k = 1:N;
%%
A = [-0.8467 0.12 -0.05;0.0156 -0.79 -0.0333;0.0156 -0.14 -0.6833];%A
B = [1 1 1]';%B
C = [-3 9 0];
D = 0;
P = [0 .01 0.1];
L=place(A',C',P)';
eig(A-L*C)
noise=randn(1,N);
sigma=0.001;
v=sqrt(sigma)*(noise-mean(noise));
%%
x(:,1) = [2 -1 4]';
xhat(:,1)=[0 0 0]'; % initial estimate
u=ones(1,N); % input signal
for i=2:N
    y(i)=C*x(:,i-1)+D*u(i)+v(i);
    yhat(i)=C*xhat(:,i-1)+D*u(i);
    x(:,i)=A*x(:,i-1)+B*u(i);
    xhat(:,i)=A*xhat(:,i-1)+B*u(i)+L*(y(i)-yhat(i));
    error(:,i)=x(:,i)-xhat(:,i);
end
%% Plots
figure(1)
sgtitle('Luenberger Observer','Interpreter','Latex','fontsize',12)
subplot(311);
plot(k,x(1,:),'r');grid on,hold on
plot(k,xhat(1,:),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_1$$','$$\hat{x}_1$$','Interpreter','Latex','fontsize',11);
subplot(312);
plot(k,x(2,:),'r');grid on,hold on
plot(k,xhat(2,:),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_2$$','$$\hat{x}_2$$','Interpreter','Latex','fontsize',11);
subplot(313);
plot(k,x(3,:),'r');grid on,hold on
plot(k,xhat(3,:),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_3$$','$$\hat{x}_3$$','Interpreter','Latex','fontsize',11);
xlabel('Sample (k)','Interpreter','Latex','fontsize',11)
set(findall(figure(1),'type','line'),'linewidth',1.2)
