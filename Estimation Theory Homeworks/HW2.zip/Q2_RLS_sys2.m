clc
clear all
close all
%%
N = 35;
k = 1:N;
%%
A = [-0.94 -0.0667 -0.1433;-0.0467 -0.9144 -0.0956;-0.0467 -0.2644 -0.7456];
B = [1 1 1]';%B
C = [-3 9 0];
D = 0;
noise=randn(1,N);
sigma=1;
v=sqrt(sigma)*(noise-mean(noise));
%%
n = 3;
x(:,1) = [2 -1 4]';
xhat(:,1)=[0 0 0]'; % initial estimate
u=ones(1,N); % input signal
P = 10^5*eye(3);
for i=1:N
    x(:,i+1)=A*x(:,i)+B*u(i);
    y(i+1)=C*x(:,i+1)+D*u(i)+v(i);
    K = P*C'/ ( 1 + C*P*C');
    P = A*[eye(3)-K*C]*P*A';
    xhat(:,i+1)=A*xhat(:,i)+B*u(i)+K*(y(i+1)-C*(A*xhat(:,i)+B*u(i)));
    yhat(i+1)=C*xhat(:,i+1)+D*u(i);
    error(:,i)=x(:,i)-xhat(:,i);
end
%% Plots
figure(1)
sgtitle('RLS Observer','Interpreter','Latex','fontsize',12)
subplot(311);
plot(k,x(1,k),'r');grid on,hold on
plot(k,xhat(1,k),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_1$$','$$\hat{x}_1$$','Interpreter','Latex','fontsize',11,'Location', 'Best');
subplot(312);
plot(k,x(2,k),'r');grid on,hold on
plot(k,xhat(2,k),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_2$$','$$\hat{x}_2$$','Interpreter','Latex','fontsize',11,'Location', 'Best');
subplot(313);
plot(k,x(3,k),'r');grid on,hold on
plot(k,xhat(3,k),'b-.'),hold off
ylim([-10 10]),xlim([1 N])
legend('$${x}_3$$','$$\hat{x}_3$$','Interpreter','Latex','fontsize',11,'Location', 'Best');
xlabel('Sample (k)','Interpreter','Latex','fontsize',11)
set(findall(figure(1),'type','line'),'linewidth',1.2)
