clc;clear all;close all
warning 'off'
%% Time of Simulation
Ts = 0.1;
Tf = 20;
t=0:Ts:Tf;
N=length(t); % Number of Samples
%% System
Gd=tf([3.548 24.76 -3.875 -15.36 -1.061],[1 -3.463 4.765 -3.257 1.107 -0.1496],Ts);
%% Input
noise = randn(1,N);
sigma = 1;
% white noise
% u = sqrt(sigma)*(noise-mean(noise));
% step
u = ones(1,N);
% square 1 Hz
% u = gensig('square',1,Tf,Ts)';
figure(1),plot(t,u),grid on
title('Input'),xlabel('Time (s)');
set(findall(figure(1),'type','line'),'linewidth',1.2)
%% Preparation data for identification
B = cell2mat(Gd.num); % Numerator polynomial coefficients
A = cell2mat(Gd.den); % Denumerator polynomial coefficients
na = length(A)-1;
nb = length(B)-1;
u_delay=[zeros(1,Gd.ioDelay) u(1:end-Gd.ioDelay)];
noise=randn(1,N);
sigma_n=0.01;
noise=sqrt(sigma_n)*(noise-mean(noise));
for i=1:N
    if (i-na)<1
        y(i)=0;
    else
        y(i)=-A(2:end)*y(i-1:-1:i-na)'+B(2:end)*u_delay(i-1:-1:i-nb)'+noise(i);
    end
end
%% RLS Algorithm
P0=1e0;
alpha1=1;
for i = 1:N
    if (i-na-nb)<1
        P1=P0*eye(na+nb); % Initial condition of covariance matrix
        theta_hat1(:,i)=randn(1,na+nb); % Initial condition of parameters
        eps(i)=0;
    else
        gamma1(:,i) = [-y(i-1:-1:i-na) u_delay(i-1:-1:i-nb)]';
        K1 = P1 * gamma1(:,i) / ( alpha1 + gamma1(:,i)' * P1* gamma1(:,i) );
        P1 = (eye(na+nb)-K1*gamma1(:,i)')*P1/alpha1;
        theta_hat1(:,i) = theta_hat1(:,i-1) + K1*(y(i) - gamma1(:,i)'*theta_hat1(:,i-1));
    end
end
%% RLS
alpha2=0.945
for i = 1:N
    if (i-na-nb)<1
        P2=P0*eye(na+nb); % Initial condition of covariance matrix
        theta_hat2(:,i)=randn(1,na+nb); % Initial condition of parameters
        eps(i)=0;
    else
        gamma2(:,i) = [-y(i-1:-1:i-na) u_delay(i-1:-1:i-nb)]';
        K2 = P2 * gamma2(:,i) / ( alpha2 + gamma2(:,i)' * P2* gamma2(:,i) );
        P2 = (eye(na+nb)-K2*gamma2(:,i)')*P2/alpha2;
        theta_hat2(:,i) = theta_hat2(:,i-1) + K2*(y(i) - gamma2(:,i)'*theta_hat2(:,i-1));
    end
end
%%
Real=[A(2:end)';B(2:end)'];
Estimation1=theta_hat1(:,end);
Estimation2=theta_hat2(:,end);
T = table(Real,Estimation1,Estimation2);
disp(T)
%% Evaluation of Identifier
for i=1:N
    if (i-na)<1
        y_est(i)=0;
    else
        y_est(i)=-theta_hat1(1:na,end)'*y_est(i-1:-1:i-na)'+theta_hat1(na+1:end,end)'*u_delay(i-1:-1:i-nb)';
    end
end
error = y-y_est;
CostFunc = 0.5*error*error'; %#ok<MHERM>
disp(['Cost Function = ',num2str(CostFunc)])
%% ploting Parameters
figure(2)
sgtitle('RLS Algorithm with Step Signal as Input','Interpreter','Latex','fontsize',12)
for i=1:5
    subplot(5,2,2*i-1)
    plot(t,theta_hat1(i,:),'b');
    grid on
    ylabel(sprintf('a%d',i),'Interpreter','Latex','fontsize',11);
    hold on
    plot(t,theta_hat2(i,:),'k');
    plot(t,A(i+1).*ones(1,N),'r--')
    hold off
end
legend('$${\alpha}=1$$','$${\alpha}=0.945$$','real','Interpreter','Latex','fontsize',9)
xlabel('Time (s)','Interpreter','Latex','fontsize',11)
for i=1:5
    subplot(5,2,2*i)
    plot(t,theta_hat1(i+5,:),'b')
    grid on
    ylabel(sprintf('b%d',i),'Interpreter','Latex','fontsize',11);
    hold on
    plot(t,theta_hat2(i+5,:),'k');
    plot(t,B(i+1).*ones(1,N),'r--')
    hold off
end
xlabel('Time (s)','Interpreter','Latex','fontsize',11)
set(findall(figure(2),'type','line'),'linewidth',1)